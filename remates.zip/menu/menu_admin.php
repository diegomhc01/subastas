<div id="menu_cli">	
	<form name="principal" method="post" action="">
		<ul>
			<li><input type="submit" name="btnmenu" id="btnmenus" value="Seguridad"></li>			
			<li><input type="submit" name="btnmenu" id="btnmenu" value="Salir"></li>
		</ul>
	</form>
</div>