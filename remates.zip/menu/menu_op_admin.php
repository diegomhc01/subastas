<div id="menu_ope_admin">	
	<form name="principal" method="post" action="">
		<ul>
			<li><input type="submit" name="btnmenu" id="btnmenu" value="Subasta"></li>
			<li><input type="submit" name="btnmenu" id="btnmenu" value="Remates"></li>
			<li><input type="submit" name="btnmenu" id="btnmenu" value="Seguridad"></li>
			<li><input type="submit" name="btnmenu" id="btnmenu" value="Hacienda"></li>
			<li><input type="submit" name="btnmenu" id="btnmenu" value="Salir"></li>
		</ul>
	</form>
</div>