<?php
	include('validar.php');
	unset($_SESSION['sopcion']);
?>