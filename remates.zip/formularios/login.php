<div id="menuh">
	<ul>
		<li id="portada">Portada</li>
		<li id="remates">Catalogo</li>
		<li id="reglamento">Reglamento</li>
		<li id="ingresar">Ingresar</li>
		<li id="registrarse">Registrarse</li>
	</ul>
</div>
<div id="rematesactivo" style="display:none;">
</div>

<div id="divregistrarse" style="display:none;">
</div>
<div id="divlogin" style="display:none;">
</div>
<div id="lsremates" style="display:none;">
</div>
<div id="publicidad" style="display:none;">
</div>