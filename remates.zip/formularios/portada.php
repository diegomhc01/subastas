<div id="portadaimg"></div>
<div id="rematesactivo"></div>
<div id="mensajep"></div>
<div id="publicidad"></div>
<div id="lsremates" style="display:none;"></div>