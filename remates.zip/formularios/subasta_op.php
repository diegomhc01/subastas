<div id="subasta">
	<!--
	<iframe src="formularios/video.htm" width="250" height="163" frameborder="0" scrolling="no"></iframe>
	<iframe src="formularios/producto.php" width="450" height="163" frameborder="0" scrolling="no"></iframe>
	<iframe src="formularios/ajax-chat.html" width="450" height="163" frameborder="0"></iframe>
	<iframe src="formularios/oferta.php" width="450" height="163" frameborder="0" scrolling="no"></iframe>	
-->
	<?php
		include('formularios/chat.php');
		include('formularios/admcreditos.php');	
	?>
</div>
