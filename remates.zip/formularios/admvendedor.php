<div id="divvendedor"  class="tab-pane fade">
    <div class="col-xs-12">
        <div class="form-group" id="fapeynomv">
            <label class="control-label" for="apeynomv">Apellido y Nombre</label>
            <span style="color:red;font-size:24px;">*</span>
            <select id="apeynomv" name="apeynomv" class="form-control selectpicker"></select>
        </div>
        <div class="form-group" id="fcuitv">
            <label class="control-label" for="cuitv">CUIT</label>
            <input type="text" id="cuitv" name="cuitv" readonly class="positive-integer form-control">
        </div>
        <div class="form-group" id="fcontactov">
            <label class="control-label" for="contactov">Contacto</label>
            <input type="text" id="contactov" name="contactov" readonly class="form-control">
        </div>
        <div class="form-group" id="ftelefonov">
            <label for="telefonov">Tel&eacute;fono</label>
            <input type="text" id="telefonov" name="telefonov" readonly class="form-control">
        </div>
        <div class="form-group" id="femailv">
            <label class="control-label" for="emailv">Correo Elec</label>
            <input type="text" id="emailv" name="emailv" readonly class="form-control">
        </div>          
    </div>
</div>