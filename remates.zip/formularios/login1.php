	<div class="col-xs-4"></div>
	<div class="col-xs-4">
		<header id="login-header">
		    <div id="login-logo">
		    <h4>Remate por Internet</h4>
		    </div>
		</header>
		<div id="login-box-inner">
		    <form method="post" name="formingresar" id="formingresar" role="form">
		        <div class="input-group"> <span class="input-group-addon"><i class="fa fa-user"></i></span>
		            <input type="text" placeholder="Correo Electrónico" name="txtusuario" id="txtusuario" class="form-control">
		        </div>
		        <div class="input-group"> <span class="input-group-addon"><i class="fa fa-key"></i></span>
		            <input type="password" placeholder="Password" name="txtclave" id="txtclave" class="form-control">
		        </div>
		        <p></p>
		        <div class="row">
		            <div class="col-xs-12">
		                <button class="btn btn-success col-xs-12" type="submit" name="btningresar" id="btningresar">Ingresar</button>
		            </div>
		        </div>
		    </form>
		</div>
	</div>
	<div class="col-xs-4"></div>
<div id="errorModal"></div>
