<div id="divformpesajed" class="tab-pane fade">
    <div class="col-xs-12">
        <div class="col-xs-6">
            <div class="form-group">
                <label class="control-label" for="ubicacion">Ubicaci&oacute;n</label>
                <input type="text" id="ubicacion" name="ubicacion" class="form-control">
            </div>
            <h3>Distancia</h3>
            <div class="form-group">
                <label class="control-label" for="arreo">Arreo</label>
                <input type="text" id="arreo" name="arreo" class="form-control">
            </div>
            <div class="form-group">
                <label class="control-label" for="camion">Cami&oacute;n</label>
                <input type="text" id="camion" name="camion" class="form-control">
            </div>
            <div class="form-group">
                <label class="control-label" for="total">Total</label>
                <input type="text" id="total" name="total" class="form-control">
            </div>
        </div>
        <div class="col-xs-6">
            <div class="form-group">
                <label class="control-label" for="balanza">Balanza</label>
                <select id="balanza" name="balanza" class="form-control selectpicker">
                    <option value="0" selected>Sin Dato</option>
                    <option value="1">P&uacute;blica</option>
                    <option value="2">Sociedad Rural</option>
                </select>
            </div>
            <div class="form-group">
                <label class="control-label" for="camions">Cami&oacute;n</label>
                <select id="camions" name="camions" class="form-control selectpicker">
                    <option value="0" selected>Sin Dato</option>
                    <option value="1">Arriba</option>
                    <option value="2">Abajo</option>
                </select>
            </div>
            <div class="form-group">
                <label class="control-label" for="desbastep">Desbaste %</label>
                <input type="text" id="desbastep" name="desbastep" class="form-control">
            </div>
            <div class="form-group">
                <label class="control-label" for="observacionesp">Observaciones</label>
                <textarea id="observacionesp" name="observacionesp" class="form-control"></textarea>
            </div>
        </div>
    </div> 
</div>