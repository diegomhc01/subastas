<div id="divsanidad" class="tab-pane fade">
    <div class="col-xs-12">
        <div class="form-group">
            <label class="control-label" for="tuberculosis">Tuberculosis</label>
            <select id="tuberculosis" name="tuberculosis" class="form-control selectpicker">
                <option value="0" selected>Sin garantía</option>
                <option value="1">Con garant&iacute;a</option>
            </select>
        </div>          
        <div class="form-group">
            <label class="control-label" for="brucelosis">Brucelosis</label>
            <select id="brucelosis" name="brucelosis" class="form-control selectpicker">
                <option value="0" selected="">Sin garantía</option>
                <option value="1">Con garant&iacute;a</option>
            </select>
        </div>          
    </div>
</div>    