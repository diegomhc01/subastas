<div id="divevaluador" class="tab-pane fade in active">
	<div class="col-xs-12">  
	    <div class="form-group" id="fevaluador">
	        <label class="control-label" for="evaluador">Evaluador</label>
	        <span style="color:red;font-size:24px;">*</span>
	        <select id="evaluador" name="evaluador" class="form-control selectpicker" required></select>
	    </div>
	    <div class="form-group" id="fnrocontrato">
	        <label class="control-label" for="nrocontrato">Nro Contrato</label>
	        <input type="text" class="form-control" id="nrocontrato" name="nrocontrato" required>
	    </div>
	</div>
</div>