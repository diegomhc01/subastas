<div id="info_registro">
	<div class="alert alert-success">
		<strong>Se ha registrado exitosamente</strong>
		<p>Se ha enviado un mensaje a su dirección de correo</p>
		<p>Los datos de acceso son la dirección de correo que ingresó y la contraseña</p>
	</div>
</div>
