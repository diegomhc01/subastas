<div id="listadohistoricoop">
	<table id="dthisotricoop" class="display" cellpadding="0"  width="100%">
		<tbody></tbody>
	</table>
</div>