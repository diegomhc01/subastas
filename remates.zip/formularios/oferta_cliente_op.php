<div id="oferta_cliente_op">
	<table id="dtofertaclienteop" class="display" cellpadding="0"  width="100%">
		<tbody></tbody>
	</table>
	<label for="mcredito">Crédito:</label>
	<input type="text" name="mcredito" id="mcredito" class="decimal-2-places">
	<input type="button" name="bmcredito" id="bmcredito" value="Actualizar a todos">
</div>