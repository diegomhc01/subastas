<div id="divmislotes">
	<input type="button" name="btnlotespasados" id="btnlotespasados" value="Pasados">
	<input type="button" name="btnlotesfuturos" id="btnlotesfuturos" value="Futuros">
	<input type="button" name="btnlotesalertas" id="btnlotesalertas" value="Alertas">
	<input type="button" name="btnlotestodos" id="btnlotestodos" value="Todos">
</div>
<div id="listalotes">
	<div id="detallelotes">
		
	</div>
</div>

