<div id="creditos">
	<table id="dtcredito" class="display" cellpadding="0"  width="100%">
		<tbody></tbody>
	</table>
</div>
<div id="updcredito" style="display:none">
	<form method="post">
		<div id="cuadrocredito">
			<label for="montocredito">Monto: </label>
			<input type="text" id="montocredito" name="montocredito" value="">
		</div>
	</form>
</div>