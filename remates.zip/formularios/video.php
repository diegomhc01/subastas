
<div id="videolote">
	<div id="playerlote"></div>

</div>