<?php
	include('scripts/buscar_lotes_rem.php');	
?>

