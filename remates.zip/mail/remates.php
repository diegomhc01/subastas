<?php
$cuerpo = '<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	</head>
	<body>
		<img src="http://www.develhard.com/intertv/remates/mail/logo.gif">
		<p>Estimado cliente:</p>
		<p>Le comunicamos que este Miércoles 22 de Junio de 2016, a las 09:30 hs realizaremos el 56° Remate de Hacienda en nuestro sitio www.brandemannsc.com.ar.</p>
		<p>Tendremos a la venta 600 vacunos de invernada y cría que ya están siendo publicados en el catálogo.</p>
		<p>Con su correo y clave podrá acceder al remate como ESPECTADOR.</p>
		<p>Si desea participar como COMPRADOR, por favor contáctenos para que le habilitemos el permiso correspondiente.</p>
		<p>Esperamos tener el agrado de verlo conectado durante el remate y aprovechamos para enviarle un saludo cordial.</p>
		<p></p>
		<p>Brandemann y Cía SC.</p>
		<p></p>
		<p></p>
		<p>Oportunamente Ud. se suscribió en nuestro sitio web para recibir recordatorios de remates. Si desea anular dicha suscripción, por favor haga clic en el siguiente AQUI</p>

	</body>
</html>';
?>